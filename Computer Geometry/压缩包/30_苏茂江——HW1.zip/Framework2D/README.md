# Framework2D

使用 ImGui 搭建简易的 2D 交互框架

目录结构和配置说明请参考[说明文档](../Homeworks/1_mini_draw/documents/README.md)

