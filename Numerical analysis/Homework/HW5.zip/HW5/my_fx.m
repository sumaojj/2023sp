function y = my_fx(x)
    y = sin(x * x + 1/3 * x);
end
